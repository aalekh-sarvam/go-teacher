#!/usr/bin/env python3
"""Parse a KataGo/KaTrain review markdown into structured JSON."""

import json
import re
import sys


def parse_game_info(text):
    """Extract game metadata from the ## Game information table."""
    info = {}
    for m in re.finditer(r'\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|', text):
        key = m.group(1).strip().lower()
        val = m.group(2).strip()
        if key == 'board size':
            info['board_size'] = int(re.search(r'(\d+)', val).group(1))
        elif key == 'komi used for analysis':
            info['komi'] = float(val)
        elif key == 'black':
            info['black_player'] = val
        elif key == 'white':
            info['white_player'] = val
        elif key == 'result recorded in sgf':
            info['result'] = val
        elif key == 'rules used for analysis':
            info['rules'] = val.split('(')[0].strip()
        elif key == 'number of moves':
            info['num_moves'] = int(val)
        elif key == 'handicap':
            info['handicap'] = int(val) if val.strip().isdigit() else 0
        elif key == 'date':
            info['date'] = val
    return info


def parse_summary(text):
    """Extract summary statistics."""
    summary = {'biggest_mistakes': [], 'turning_points': []}

    # Biggest mistakes table rows
    # Format: | 17 | F6 | 7.4 | 0.1% → 0.0% | big mistake | G7 | middlegame |
    mistake_pattern = re.compile(
        r'\|\s*(\d+)\s*\|\s*([A-T]\d+|pass)\s*\|\s*([\d.]+)\s*\|'
        r'\s*([\d.]+)%\s*→\s*([\d.]+)%\s*\|\s*'
        r'(big mistake|mistake|inaccuracy|blunder|good|best/excellent)\s*\|'
        r'\s*([A-T]\d+|pass)\s*\|\s*(\w+)\s*\|'
    )
    for m in mistake_pattern.finditer(text):
        summary['biggest_mistakes'].append({
            'move_number': int(m.group(1)),
            'played_move': m.group(2),
            'point_loss': float(m.group(3)),
            'winrate_before': m.group(4) + '%',
            'winrate_after': m.group(5) + '%',
            'category': m.group(6),
            'preferred_move': m.group(7),
            'phase': m.group(8),
        })

    # Turning points
    tp_match = re.search(
        r'### Turning points\s*\n(.*?)(?=\n## |\Z)', text, re.DOTALL)
    if tp_match:
        for line in tp_match.group(1).strip().split('\n'):
            line = line.strip().lstrip('- ').strip()
            if line:
                summary['turning_points'].append(line)

    return summary


def parse_compact_moves(text):
    """Parse the appendix compact move list."""
    moves = []
    # Find code block after "## Appendix: compact move list"
    # There's descriptive text between heading and code block
    appendix_match = re.search(
        r'## Appendix: compact move list.*?```\s*\n(.*?)```', text, re.DOTALL)
    if not appendix_match:
        return moves

    block = appendix_match.group(1)
    # Each line: "  1 B F4    loss   0.5  rank #11  wr  11.2%  W+0.9"
    line_pattern = re.compile(
        r'\s*(\d+)\s+([BW])\s+(\S+)\s+loss\s+([\d.+-]+)\s+rank\s+(\S+)\s+wr\s+(\S+)\s+(\S+)'
    )
    for line in block.strip().split('\n'):
        m = line_pattern.match(line)
        if m:
            moves.append({
                'number': int(m.group(1)),
                'color': m.group(2),
                'move': m.group(3),
                'point_loss': float(m.group(4)),
                'rank': m.group(5),
                'winrate_after': m.group(6),
                'score_after': m.group(7),
            })
    return moves


def parse_move_analysis(text):
    """Parse each move's detailed analysis."""
    moves_detail = {}

    # Split by "### Move N: Color Coord"
    move_sections = re.split(r'(?=### Move \d+:)', text)

    for section in move_sections:
        header_match = re.match(r'### Move (\d+): (Black|White) (\S+)', section)
        if not header_match:
            continue

        move_num = int(header_match.group(1))
        color = header_match.group(2)[0].upper()
        coord = header_match.group(3)

        detail = {
            'number': move_num,
            'color': color,
            'move': coord,
            'candidates': [],
        }

        # Point loss: "Point loss for Black: +7.3 pts (not searched by KataGo)"
        loss_match = re.search(
            r'Point loss for \w+:\s*([\d.+-]+)\s*pts\s*\(([^)]+)\)', section)
        if loss_match:
            detail['point_loss'] = float(loss_match.group(1))
            detail['rank_info'] = loss_match.group(2)

        # Verdict: "Verdict: **big mistake**."
        verdict_match = re.search(r'Verdict:\s*\*\*([^*]+)\*\*', section)
        if verdict_match:
            detail['verdict'] = verdict_match.group(1).strip()

        # Phase: "Phase: opening."
        phase_match = re.search(r'Phase:\s*(\w+)\.', section)
        if phase_match:
            detail['phase'] = phase_match.group(1)

        # Evaluation: "Black winrate 0.3% → 0.1%, score W+7.5 → W+14.7."
        eval_match = re.search(
            r'winrate\s*([\d.]+)%\s*→\s*([\d.]+)%.*?score\s*(\S+)\s*→\s*(\S+)',
            section)
        if eval_match:
            detail['winrate_before'] = eval_match.group(1) + '%'
            detail['winrate_after'] = eval_match.group(2) + '%'
            detail['score_before'] = eval_match.group(3)
            detail['score_after'] = eval_match.group(4).rstrip('.')

        # KataGo preferred: "KataGo preferred **E7** (0.3%, W+7.4), expecting: E7 E6 ..."
        pref_match = re.search(
            r'KataGo preferred\s+\*\*([A-T]\d+|pass)\*\*\s*\(([\d.]+%),\s*(\S+)\)',
            section)
        if pref_match:
            detail['preferred_move'] = pref_match.group(1)
            detail['preferred_winrate'] = pref_match.group(2)
            detail['preferred_score'] = pref_match.group(3).rstrip('.')

        # Preferred PV: "expecting: E7 E6 D5 C5 F6 ..."
        pv_match = re.search(
            r'KataGo preferred\s+\*\*(?:[A-T]\d+|pass)\*\*.*?expecting:\s*([A-TJ]\d+(?:\s+[A-TJ]\d+|\s+pass)*)',
            section)
        if pv_match and pv_match.group(1):
            detail['preferred_pv'] = pv_match.group(1).split()

        # Played PV: "expected continuation after E6: E6 ..."
        played_pv_match = re.search(
            r'expected continuation after\s+' + re.escape(coord) + r':\s*([A-TJ]\d+(?:\s+[A-TJ]\d+|\s+pass)*)',
            section)
        if played_pv_match:
            detail['played_pv'] = played_pv_match.group(1).split()

        # Candidates table
        # | 1 | E7 | 0.3% | W+7.4 | 172 | 30.6% | E7 E6 D5 C5 F6 D8 F8 D2 C6 C7 |
        # | 11 | F4 ← played | 7.1% | W+0.7 | 1 | 0.5% | F4 |
        cand_section_match = re.search(
            r'Candidates in the position before this move:\s*\n(.*?)(?=\n###|\n##|\nPosition after|\Z)',
            section, re.DOTALL)
        if cand_section_match:
            cand_text = cand_section_match.group(1)
            # Match table rows - move column can have "← played" suffix
            cand_pattern = re.compile(
                r'\|\s*(\d+)\s*\|\s*([A-T]\d+|pass)(\s*←\s*played)?\s*\|'
                r'\s*([\d.]+)%\s*\|\s*(\S+)\s*\|\s*(\d+)\s*\|\s*([\d.]+)%\s*\|'
                r'\s*(.*?)\s*\|'
            )
            for cm in cand_pattern.finditer(cand_text):
                pv_str = cm.group(8).strip()
                if pv_str == '—':
                    pv_str = ''
                detail['candidates'].append({
                    'rank': int(cm.group(1)),
                    'move': cm.group(2),
                    'played': cm.group(3) is not None,
                    'winrate': cm.group(4) + '%',
                    'score': cm.group(5),
                    'visits': int(cm.group(6)),
                    'policy': cm.group(7) + '%',
                    'pv': pv_str.split() if pv_str else [],
                })

        # Board diagram
        diag_match = re.search(
            r'Position after move \d+:\s*\n```\s*\n(.*?)```', section, re.DOTALL)
        if diag_match:
            detail['board_diagram'] = diag_match.group(1).strip()

        moves_detail[move_num] = detail

    return moves_detail


def parse_review(text):
    """Main parsing function."""
    result = {}
    result['game_info'] = parse_game_info(text)
    result['summary'] = parse_summary(text)
    result['moves'] = parse_compact_moves(text)
    result['move_details'] = parse_move_analysis(text)
    return result


def main():
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <input.md> <output.json>")
        sys.exit(1)

    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        text = f.read()

    result = parse_review(text)

    with open(sys.argv[2], 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    print(f"Parsed {len(result['moves'])} moves", file=sys.stderr)
    print(f"Found {len(result['summary']['biggest_mistakes'])} biggest mistakes",
          file=sys.stderr)
    print(f"Found {len(result['move_details'])} move details", file=sys.stderr)


if __name__ == '__main__':
    main()
