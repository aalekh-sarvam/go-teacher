---
name: go-game-teacher
description: "Transforms KataGo-analyzed Go game reviews (markdown format from KaTrain/KataGo) into interactive HTML lessons for beginners. Use this skill whenever a user uploads a Go game review, analysis, or KataGo/KaTrain markdown and wants to learn from their mistakes. Triggers on phrases like 'analyse this Go game', 'review my Go game', 'help me improve at Go', or any mention of KataGo/KaTrain game reviews. Produces a self-contained HTML file with clickable board positions, interactive explanations of key mistakes, and practice puzzles that test the same concepts with different board configurations."
allowed-tools: execute_code terminal read_file write_file workspace_output workspace_emit present_output web_search web_get_contents
---

# Go Game Teacher

Turn a KataGo game review markdown into an interactive HTML lesson that teaches a beginner what they got wrong and helps them practice the same concepts with fresh puzzles.

## What you need

- **Input**: A markdown file produced by KataGo/KaTrain game analysis (the user uploads this)
- **Output**: A single self-contained HTML file with interactive Go boards, explanations, and puzzles

## Workflow

### 1. Parse the review

Run the parsing script on the uploaded markdown file. Locate the script at `<sandbox_dir>/scripts/parse_review.py` (the sandbox_dir comes from the `skill_view` response that loaded this skill).

```
python <sandbox_dir>/scripts/parse_review.py <input.md> <output.json>
```

This extracts game metadata, the full move list, per-move analysis (point loss, verdict, phase, KataGo's preferred move, candidate moves with PVs), board diagrams, and summary statistics into structured JSON.

Read the output JSON. The `biggest_mistakes` array and the `moves` array are the most important sections for choosing lessons.

### 2. Identify the top 2-3 teaching moments

From the parsed data, find the player's biggest mistakes (highest point loss in the `biggest_mistakes` array). Don't just pick the top by number — group them by theme so each lesson teaches a distinct concept.

Read `references/go-teaching-concepts.md` for how to categorize mistakes into themes (direction of play, shape, reading/tactics, timing of invasions, endgame counting, responding to threats, overplays/underplays) and how to explain each to a beginner.

Pick 2-3 mistakes that:
- Have the highest point loss
- Represent distinct concepts (avoid teaching the same thing twice)
- Are instructive for a beginner (early/mid-game mistakes are usually more valuable than endgame counting errors)

Also look for missed opportunities — moves where KataGo's preferred move was significantly better and would have changed the game's direction.

### 3. Research common patterns and remedies online

Before writing the lesson content, search the web to validate and enrich your understanding of each chosen mistake. The goal is to ground the explanations in established Go teaching rather than relying solely on your own interpretation of the KataGo data.

For each of the 2-3 mistakes you've identified, search for:

- **The pattern name**: Is this a recognized mistake pattern? (e.g., "playing under strong stones", "empty triangle shape", "premature invasion", "tenuki when threatened", "reverse sente endgame"). Search for the theme + "Go" + "beginner" or "mistake".
- **How strong players and teachers explain it**: Look for how Go instructors, books, or established resources (Go Magic, Sensei's Library, GoProblems, learn-go.net) explain this concept. You're looking for memorable phrasing, analogies, and the standard corrective advice.
- **How to avoid it**: Search for drills, habits, or rules of thumb that address this weakness. (e.g., "before invading, count your nearby stones"; "before playing, check if your opponent's last move threatens anything"; "in the endgame, always count the biggest point available").

Use `web_search` for the initial query, and `web_get_contents` to read promising results in full. Search for terms like:
- `"direction of play" Go beginner mistake`
- `"playing under strong stones" Go`
- `"premature invasion" Go weiqi`
- `"endgame counting" Go big points first`
- `"tenuki" Go when to respond`

Also search for the specific board situation if it maps to a known joseki or fuseki pattern — understanding whether the player deviated from a standard sequence adds valuable context.

Distill what you find into 2-3 bullet points per mistake: the pattern name, the standard teaching on why it's wrong, and the specific advice for avoiding it. Use these to enrich the lesson content in the next step. If the search doesn't surface anything useful for a particular mistake, proceed with your own analysis — the research is enrichment, not a blocker.

### 4. Write the lesson content

For each chosen mistake, write:

- **What happened**: The position, what the player played, what KataGo preferred
- **Why it's wrong**: Explain in beginner-friendly language. Don't just say "this loses 7 points" — explain the strategic concept. Why does E7 work better than E6? What is the shape? What is the direction? Incorporate insights from your web research — if this is a recognized pattern, name it and cite how established teachers explain it.
- **The variation**: Walk through KataGo's preferred PV and explain what happens
- **The principle**: A one-sentence takeaway the beginner can remember. Draw on the "how to avoid it" advice from your research — give the student an actionable habit or rule of thumb, not just an abstract principle.

Also write an overall game summary (2-3 paragraphs) with stylistic feedback: what the player does well, what their main weakness is, what phase of the game needs the most work.

### 4a. Highlight moves played well

From the parsed data, find 1-3 moves where the player got it right — moves with very low point loss that matched KataGo's top choice, or where the player found a creative or instructive move. These go in the `good_moves` array.

For each good move:
- The move number and coordinate (the board replays to show the position with the move marked green)
- A fun **kyu/dan rating** — estimate what level of player would typically find this move. Be generous and encouraging; this is meant to motivate, not to be a precise rating. (e.g., "3 kyu", "1 dan", "5 kyu")
- An explanation of why the move was good in beginner-friendly language

Place this section between the lessons and the puzzles — it gives the student a confidence boost before tackling the exercises.

### 5. Design practice puzzles

For each lesson's concept, design 1-2 puzzles with different board positions that test the same principle. Read `references/go-teaching-concepts.md` for puzzle design guidance per theme.

Each puzzle needs:
- A fresh board position (not from the game) that isolates the concept
- The opponent's last move — specify it as `opponent_last_move` so it gets marked with a blue square on the board, giving the student the same context they'd have in a real game
- The correct move(s) and why they work
- Common wrong moves and why they fail
- A hint for when the student is stuck

Keep positions simple — a beginner should be able to read them out in their head. 9x9 or smaller fragments of larger boards work well. Specify positions as explicit stone placements (GTP coordinates like "E5", "D4").

### 5a. Write the Go concepts & resources section

For each concept covered in the lessons, write a `concepts_learned` entry. This section appears after the puzzles and gives the student formal vocabulary, further reading, and memorable stories.

For each concept:
- **Term**: The English name (e.g., "Direction of Play", "Sente and Gote", "Shape", "Liberties")
- **Japanese**: The Japanese term with kanji and romaji (e.g., "方向 (Hōkō)", "先手 (Sente)"). Include the kanji, the romaji reading in parentheses, and optionally the English translation. Read `references/go-teaching-concepts.md` for a list of common Japanese Go terms.
- **Description**: 2-3 sentences explaining the concept clearly for a beginner
- **Resources**: 2-3 links to external resources. Search the web for the best links — Sensei's Library, Go Magic, YouTube Go tutorials, or other established resources. Include the title and URL.
- **Anecdote**: An interesting historical story, Go proverb, or memorable fact related to the concept. Think stories about famous players (Go Seigen, Shusaku, Lee Sedol, AlphaGo), famous proverbs ("Play on the open side", "A group with two eyes lives forever"), or historical moments. Keep it 2-4 sentences and make it memorable.

This is also where your web research from Step 3 pays off — the pattern names, teaching explanations, and remedies you found can be formalized here with proper terminology and linked resources.

### 6. Generate the HTML

Write the lesson content as a JSON file following the schema in `references/html-build-guide.md`. Then run the generation script:

```
python <sandbox_dir>/scripts/generate_lesson.py <parsed.json> <lesson.json> <output.html>
```

This produces a self-contained HTML file with:
- A lightweight canvas-based Go board renderer (no external dependencies, works offline)
- Interactive lesson boards with move navigation (position → played move → better move), with the opponent's last move marked on the board in all states so the student has full context
- Puzzle boards with click-to-answer and instant feedback
- Styled explanations and game summary

### 7. Deliver

Save the HTML file and deliver it to the user. If writing with Python (which may seek), write to `/scratch/work/` first, then promote with `workspace_emit`, then `present_output`.

## Tone and style

Write as a patient Go teacher talking to a beginner:

- Explain WHY, not just WHAT. "E7 is better than E6 because it connects your stones and prevents White from cutting" — not "E7 is 7 points better."
- Use concrete language. "This stone is in atari" not "this move has suboptimal tactical properties."
- Be encouraging. Frame mistakes as learning opportunities, not failures.
- Connect concepts to memorable principles. "When your opponent's stone is strong, don't play right next to it — play where you can develop freely."

## Reference files

- `references/katago-review-format.md` — How the KataGo markdown is structured, what each field means, how to read diagrams and candidate tables
- `references/go-teaching-concepts.md` — Go concepts, mistake themes, how to explain them to beginners, how to design puzzles for each theme
- `references/html-build-guide.md` — Lesson JSON schema, Go board renderer API, HTML structure, puzzle interaction patterns
