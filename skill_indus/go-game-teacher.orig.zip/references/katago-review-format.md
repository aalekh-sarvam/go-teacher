# KataGo Review Markdown Format

This document describes the structure of the markdown file produced by KaTrain/KataGo game analysis. The parsing script (`scripts/parse_review.py`) handles extraction automatically, but understanding the format helps you interpret the data and write better lessons.

## Top-level structure

```
# Go game review: <Black player> vs <White player>

## Game information          — metadata table
## How to read this document — guide (skip during parsing)
## Summary                   — statistics tables
## Move-by-move analysis     — per-move sections (### Move N)
## Final position            — end-of-game position
## Appendix: compact move list — one-line-per-move summary
```

## Game information table

Standard markdown table with fields: Black, White, Result, Date, Board size, Handicap, Komi, Rules, Number of moves, Analysis strength.

Key fields the parser extracts: `board_size`, `komi`, `rules`, `number_of_moves`, player names, and result.

## Summary section

### Accuracy by player

Per-player stats: moves played, mean/median point loss, total points lost, match rate with KataGo's top choice, top-3 match rate, and a breakdown by category (best/excellent, good, inaccuracy, mistake, big mistake, blunder).

### Point loss by phase

Breakdown of mean and total loss across phases: opening (moves 1–16 on 9x9, adjust for larger boards), middlegame, endgame. Useful for telling the student which phase needs work.

### Game flow

Black winrate and score lead after every 10th move, with a visual bar chart. Shows the trajectory of the game.

### Biggest mistakes

A table per player listing moves sorted by point loss: Move number, played move, loss (pts), winrate change, category, KataGo's preferred move, phase. This is the primary input for selecting which mistakes to teach.

### Turning points

Moves where the winrate changed dramatically. These are often the most instructive moments.

## Move-by-move analysis

Each move has its own `### Move N: Color Coordinate` section.

### Fields per move

- **Evaluation**: `Black winrate X% → Y%, score A → B.` Shows before/after.
- **Point loss**: `Point loss for <color>: Z pts (KataGo's #N choice)` or `(not searched by KataGo)`. "not searched" means KataGo didn't consider the move at all — often a sign of an unnatural or very bad move.
- **Verdict**: Category label: best/excellent, good, inaccuracy, mistake, big mistake, blunder.
- **Phase**: opening, middlegame, endgame.
- **Expected continuation after played move**: The PV from the played move.
- **KataGo preferred**: The top candidate move with its winrate, score, and PV.
- **Comment in the game record** (optional): Raw KaTrain comment with additional details including policy rank and top policy move.

### Candidates table

For each move, a table of KataGo's top candidates:

| # | Move | Black winrate | Score | Visits | Policy | Expected continuation |
|---|------|--------------|-------|--------|--------|----------------------|

- **#**: KataGo's ranking (1 = top choice). The played move appears with `← played` if it was in the candidate list.
- **Move**: GTP coordinate (e.g., E5, pass).
- **Black winrate**: KataGo's estimate of Black's winning probability after this move.
- **Score**: Expected margin (e.g., W+7.4 means White leads by 7.4).
- **Visits**: How many search visits KataGo spent on this move.
- **Policy**: KataGo's raw policy probability (first-move intuition before search).
- **Expected continuation**: The principal variation (PV) — alternating moves starting with the mover.

### ASCII board diagrams

Included for mistakes with ≥ 3 point loss. Shows the position after the move:

```
    A B C D E F G H J
 9  . . . . . . . . .  9
 8  . . . . X . . . .  8
 ...
 2  . . . . # . . . .  2
    A B C D E F G H J
```

Legend:
- `X` = Black stone
- `O` = White stone
- `+` = star point (empty)
- `#` = Black stone just played
- `@` = White stone just played
- `1`, `2`, `3` = KataGo's preferred alternatives (numbered by candidate ranking)

## Compact move list (appendix)

One line per move, in a code block:

```
  1 B F4    loss   0.5  rank #11  wr  11.2%  W+0.9
  2 W D6    loss  -0.2  rank #1   wr  10.6%  W+1.1
```

Fields: move number, color (B/W), coordinate, point loss, KataGo rank (#N or `-` for not searched), Black winrate after move, score after move.

The parser uses this as the canonical move list for reconstructing board positions.

## Coordinates

GTP convention: columns A–T (letter I is skipped), rows 1–19 from bottom to top. So on a 9x9 board, columns are A–J and rows 1–9. `E5` is the center point. `pass` is a pass move.

## Category thresholds

Point loss categories (from the "How to read" section):
- **best/excellent**: < 0.5 pts
- **good**: < 1.5 pts
- **inaccuracy**: < 3 pts
- **mistake**: < 6 pts
- **big mistake**: < 12 pts
- **blunder**: ≥ 12 pts

## Important note on PVs

KataGo's principal variation shows what KataGo expects both sides to play, but it may not contain the human-explainable "reason" a move is right or wrong. In many positions, the key tactic only appears in a line where both sides "double down" — which is NOT a PV because it involves one side making a "mistake" by continuing. When explaining a position, consider demonstrating the critical variation yourself rather than relying solely on the PV.